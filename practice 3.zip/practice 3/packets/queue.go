package packets

type Queue[T any] struct {
    data []T
}

func (q *Queue[T]) Enqueue(val T) {
    q.data = append(q.data, val)
}

func (q *Queue[T]) Dequeue() T {
    if len(q.data) == 0 {
        var zero T
        return zero
    }
    val := q.data[0]
    q.data = q.data[1:]
    return val
}
