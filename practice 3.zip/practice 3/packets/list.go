package packets

type Node[T any] struct {
    value T
    next  *Node[T]
}

type List[T any] struct {
    head *Node[T]
}

func (l *List[T]) Add(val T) {
    newNode := &Node[T]{value: val}
    if l.head == nil {
        l.head = newNode
    } else {
        curr := l.head
        for curr.next != nil {
            curr = curr.next
        }
        curr.next = newNode
    }
}

func (l *List[T]) Print() {
    curr := l.head
    for curr != nil {
        print(curr.value, " -> ")
        curr = curr.next
    }
    println("nil")
}
