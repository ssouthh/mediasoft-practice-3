package main

import (
    "fmt"
    "go-practice/packets"
)

func main() {
    s := packets.Stack[int]{} // стек
    s.Push(10)
    s.Push(20)
    fmt.Println("Pop из стека:", s.Pop())

    q := packets.Queue[int]{} // очередь
    q.Enqueue(1)
    q.Enqueue(2)
    fmt.Println("Dequeue из очереди:", q.Dequeue())

    list := packets.List[int]{} // список
    list.Add(5)
    list.Add(15)
    list.Print()
}
